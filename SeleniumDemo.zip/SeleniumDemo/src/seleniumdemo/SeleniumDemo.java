/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Main.java to edit this template
 */
package seleniumdemo;

import org.openqa.selenium.By;
import org.openqa.selenium.chrome.ChromeDriver;
import org.openqa.selenium.edge.EdgeDriver;

/**
 *
 * @author megha
 */
public class SeleniumDemo {

    /**
     * @param args the command line arguments
     */
      public static void main(String[] args) throws InterruptedException {
        //variable declation for checking pageTitle
        String pageTitle;
        //setting property for webdriver
        System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
          EdgeDriver ed = new EdgeDriver();
        
        //Step 1 : maximising broswers window
        ed.manage().window().maximize(); 
        
        //Step 2 : Getting url 
        ed.get("https://timesofindia.indiatimes.com/topic/information-technology");
        
        //Step 3 : Take page title
        pageTitle = ed.getTitle();
        System.out.println("Title of page is " + pageTitle);
        
        
        //Step 4 : Comparing title
        if (pageTitle.equalsIgnoreCase("INFORMATION TECHNOLOGY")) {
            System.out.println("Page title matches 'INFORMATION TECHNOLOGY'");
        } else {
            System.out.println("Page title does not match 'INFORMATION TECHNOLOGY'");
        }
        Thread.sleep(3000);
        
        ed.findElement(By.id("Articles")).click();
        Thread.sleep(2000);
        
        ed.findElement(By.xpath("//*[@id=\"storyBody\"]/div/div[2]/div/div[1]/div/div[1]/div/div[6]/a/div/div[1]/span")).click();
        Thread.sleep(2000);
       
        //printing the title of article
        System.out.println(ed.getTitle());
        ed.quit();

    }
}
