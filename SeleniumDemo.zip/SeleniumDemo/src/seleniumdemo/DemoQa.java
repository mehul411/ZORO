/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package seleniumdemo;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;
import org.openqa.selenium.interactions.Actions;

/**
 *
 * @author megha
 */
public class DemoQa {
    public static void main(String[] args) throws InterruptedException {
         //variable declation for checking pageTitle
        String pageTitle;
        //setting property for webdriver
        System.setProperty("webdriver.chrome.driver", "D:\\chromedriver.exe");
          EdgeDriver ed = new EdgeDriver();
        
        //Step 1 : maximising broswers window
        ed.manage().window().maximize(); 
        
        //Step 2 : Getting url 
        ed.get("https://demoqa.com/radio-button");
        
        //Step 3 : Take page title
        pageTitle = ed.getTitle();
        System.out.println("Title of page is " + pageTitle);
        
        
        //Step 4 : Comparing title
        if (pageTitle.equalsIgnoreCase("INFORMATION TECHNOLOGY")) {
            System.out.println("Page title matches 'INFORMATION TECHNOLOGY'");
        } else {
            System.out.println("Page title does not match 'INFORMATION TECHNOLOGY'");
        }
        Thread.sleep(3000);
        
        
        
        
//        ed.findElement(By.id("ahg2V")).click();
//        Thread.sleep(5000);
        
        ed.findElement(By.xpath("//*[@id=\"app\"]/div/div/div/div[2]/div[2]/div[4]/label")).click();
        Thread.sleep(3000);


        //printing the title of article
        System.out.println(ed.getTitle());
        ed.quit();

    }

}
