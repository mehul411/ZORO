/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package seleniumdemo;

import org.openqa.selenium.By;
import org.openqa.selenium.edge.EdgeDriver;

/**
 *
 * @author megha
 */
public class EgovDemo {
    public static void main(String[] args) throws InterruptedException {
        EdgeDriver fd=new EdgeDriver();
            fd.manage().window().maximize();
            fd.get("https://charusat.edu.in:912/eGovernance/");
            System.out.println("Title of page is "+fd.getTitle());
            fd.findElement(By.name("txtUserName")).sendKeys("23mca022");
            fd.findElement(By.name("txtPassword")).sendKeys("260602");
            Thread.sleep(3000);
            fd.findElement(By.id("btnLogin")).click();
            Thread.sleep(3000);
            fd.findElement(By.xpath("/html/body/form/div[3]/div[1]/ul/li[1]/a/i")).click();
            Thread.sleep(1000);
            fd.findElement(By.xpath("//*[@id=\"LinkProfile\"]")).click();
            Thread.sleep(2000);
            fd.findElement(By.xpath("//*[@id=\"ctl00_ContentPlaceHolder1_pageActions_lnkSave\"]")).click();
            Thread.sleep(2000);
            fd.findElement(By.xpath("/html/body/div[4]/div[7]/div/button")).click();
            Thread.sleep(2000);
            fd.close();
    }
    
}
